#include "CAdmin.h"

using namespace std;

int main()
{
    CAdmin admin;
    admin.Manage();
    return 0;
}
